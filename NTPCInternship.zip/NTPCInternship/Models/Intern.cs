﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace NTPCInternship.Models
{
    public class Intern
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Skill { get; set; }
        public string Availability { get; set; }
        public Intern()
        {

        }
    }
}
